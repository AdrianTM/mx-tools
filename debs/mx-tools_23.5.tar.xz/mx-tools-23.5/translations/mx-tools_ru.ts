<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>MX Tools</source>
        <translation>MX Инструменты</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="53"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="56"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="63"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Close application</source>
        <translation>Закрыть приложение</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="130"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="137"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <source>Manual</source>
        <translation>Руководство</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation>Эти приложения MX экономят время и усилия при выполнении важных задач.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Hide individual tools from the menu</source>
        <translation>Скрыть отдельные инструменты из меню</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="409"/>
        <source>About MX Tools</source>
        <translation>О программе MX Инструменты</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="411"/>
        <source>Configuration Tools for MX Linux</source>
        <translation>Средства настройки MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="414"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="415"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="43"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="44"/>
        <location filename="../about.cpp" line="54"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="45"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="67"/>
        <source>&amp;Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
</TS>
