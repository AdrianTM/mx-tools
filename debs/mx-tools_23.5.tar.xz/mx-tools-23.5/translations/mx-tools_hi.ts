<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>MX Tools</source>
        <translation>MX साधन</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="53"/>
        <source>About this application</source>
        <translation>इस अनुप्रयोग के बारे में</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="56"/>
        <source>About...</source>
        <translation>बारे में...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="63"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Close application</source>
        <translation>अनुप्रयोग बंद करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="130"/>
        <source>Close</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="137"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <source>Manual</source>
        <translation>सहायता गाइड</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation>ये MX अनुप्रयोग महत्वपूर्ण कार्यों के दौरान समय व प्रयास की बचत करते हैं।</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Hide individual tools from the menu</source>
        <translation>मेन्यू में इकलौते साधनों को प्रदर्शित न करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>search</source>
        <translation>खोज</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="409"/>
        <source>About MX Tools</source>
        <translation>MX साधनों के बारे में</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>Version: </source>
        <translation>संस्करण :</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="411"/>
        <source>Configuration Tools for MX Linux</source>
        <translation>MX लिनक्स हेतु विन्यास साधन</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="414"/>
        <source>Copyright (c) MX Linux</source>
        <translation>कॉपीराइट (c) एमएक्स लिनक्स</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="415"/>
        <source>%1 License</source>
        <translation>%1 लाइसेंस</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="43"/>
        <source>License</source>
        <translation>लाइसेंस</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="44"/>
        <location filename="../about.cpp" line="54"/>
        <source>Changelog</source>
        <translation>बदलाव सूची</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="45"/>
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="67"/>
        <source>&amp;Close</source>
        <translation>बंद करें (&amp;C)</translation>
    </message>
</context>
</TS>
