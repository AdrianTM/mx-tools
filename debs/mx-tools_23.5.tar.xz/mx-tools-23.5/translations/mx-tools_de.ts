<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>MX Tools</source>
        <translation>MX Tools</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="53"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="56"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="63"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Close application</source>
        <translation>Anwendung schließen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="130"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="137"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <source>Manual</source>
        <translation>Handbuch</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation>Diese MX-Anwendungen ersparen Zeit und Mühe bei wichtigen Aufgaben (z.B. Remastern der Distro)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Hide individual tools from the menu</source>
        <translation>Werkzeuge nicht nochmal einzeln im Menü zeigen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>search</source>
        <translation>Suche </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="409"/>
        <source>About MX Tools</source>
        <translation>Impressum MX Tools</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="411"/>
        <source>Configuration Tools for MX Linux</source>
        <translation>Konfigurationswerkzeuge für MX</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="414"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="415"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="43"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="44"/>
        <location filename="../about.cpp" line="54"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="45"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="67"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
</context>
</TS>
