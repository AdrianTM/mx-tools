<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>MX Tools</source>
        <translation>MX Tools</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="53"/>
        <source>About this application</source>
        <translation>Over deze toepassing</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="56"/>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="63"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Close application</source>
        <translation>Sluit applicatie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="130"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="137"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <source>Manual</source>
        <translation>Handleiding</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation>Deze MX toepassingen besparen tijd en moeite met belangrijke taken.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Hide individual tools from the menu</source>
        <translation>Verberg individuele gereedschappen van het menu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>search</source>
        <translation>zoeken</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="477"/>
        <source>About MX Tools</source>
        <translation>Over MX Gereedschappen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>Version: </source>
        <translation>Versie:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="479"/>
        <source>Configuration Tools for MX Linux</source>
        <translation>Configuratiegereedschappen voor MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="482"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="483"/>
        <source>%1 License</source>
        <translation>%1 Licentie</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="61"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="62"/>
        <location filename="../about.cpp" line="72"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="63"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="85"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
</context>
</TS>