<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ko">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>MX Tools</source>
        <translation>MX Tools</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="53"/>
        <source>About this application</source>
        <translation>이 애플리케이션 정보</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="56"/>
        <source>About...</source>
        <translation>About...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="63"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Close application</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="130"/>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="137"/>
        <source>Alt+N</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <source>Manual</source>
        <translation>매뉴얼</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Hide individual tools from the menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="309"/>
        <source>search</source>
        <translation>검색</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="477"/>
        <source>About MX Tools</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>Version: </source>
        <translation>버전:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="479"/>
        <source>Configuration Tools for MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="482"/>
        <source>Copyright (c) MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="483"/>
        <source>%1 License</source>
        <translation>%1 라이센스</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="61"/>
        <source>License</source>
        <translation>라이센스</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="62"/>
        <location filename="../about.cpp" line="72"/>
        <source>Changelog</source>
        <translation>변경 로그</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="63"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="85"/>
        <source>&amp;Close</source>
        <translation>닫기(&amp;C)</translation>
    </message>
</context>
</TS>