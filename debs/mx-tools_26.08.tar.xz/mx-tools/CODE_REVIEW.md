# Code Review

**Scope:** entire codebase (main.cpp, mainwindow.{cpp,h}, flatbutton.{cpp,h}, about.{cpp,h}, CMakeLists.txt, build.sh, release.sh, PKGBUILD, debian/*, help/mx-tools.1)
**Date:** 2026-07-27
**Verdict:** Application source (main.cpp, mainwindow.*, flatbutton.*, about.*) is solid with no high-confidence bugs found; the Arch Linux packaging script has two `install` invocations that always fail and are silently swallowed, dropping files from the built package.

## Action items

1. - [x] **`install -D` with a glob source and directory-style destination always fails** — `PKGBUILD:52`
   `install -Dm644 help/*.1 "${pkgdir}/usr/share/man/man1/" 2>/dev/null || true`. Verified by running this exact command locally: with `-D` and a single source argument, GNU coreutils `install` treats the last argument as `SOURCE DEST-FILE`, not `SOURCE DEST-DIR` — a destination ending in `/` is then an invalid file path and the command exits 1 ("cannot create regular file ...: Not a directory"). With the `help/mx-tools.1` file that is actually committed in this repo, this command fails every time, and `2>/dev/null || true` hides the failure so `makepkg` reports success while the man page is missing from the package. Fix using `-t`: `install -Dm644 -t "${pkgdir}/usr/share/man/man1/" help/*.1` (the pattern already used correctly for html/css/etc. in the loop just below), or pre-create the directory with `install -dm755` first and drop `-D`.

2. - [x] **Same bug already drops all translations from the Arch package** — `PKGBUILD:40`
   `install -Dm644 build/*.qm "${pkgdir}/usr/share/mx-tools/locale/" 2>/dev/null || true` has the identical destination-with-trailing-slash defect. Verified locally with both a single `.qm` file and multiple `.qm` files — both fail the same way. Every translation file is silently omitted from Arch builds. Apply the same fix: `install -Dm644 -t "${pkgdir}/usr/share/mx-tools/locale/" build/*.qm`.
