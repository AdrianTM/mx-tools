# Repository Guidelines

## Project Structure & Module Organization
Source lives in the repo root: `main.cpp` boots the Qt app, `mainwindow.{cpp,h,ui}` drives layout and tool filtering, and `flatbutton.{cpp,h}` defines the dashboard buttons. Dialog helpers such as `about.{cpp,h}` sit alongside. Assets are centralized in `images.qrc`, while raw icons reside in `icons/` and help copy lives in `help/`. Localization strings are under `translations/` and `translations-desktop-file/`, and Debian packaging logic is in `debian/`. Generated artifacts (e.g., `build/`, `release/`, `mx-tools_autogen/`) should stay out of commits.

## Build, Test, and Development Commands
- `./build.sh` — configures a Ninja build in `build/` and emits the `mx-tools` binary under `build/` (release defaults).
- `./build.sh --debug` — enables debug flags and symbols for stepping through Qt widgets.
- `./build.sh --clang` or `./build.sh --debian` — switches the compiler or produces a Debian package respectively.
- `cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release` followed by `cmake --build build` — manual path for CI scripts.
Launch the app for manual checks via `./build/mx-tools` (or the `debug/` binary when using that preset).

## Coding Style & Naming Conventions
Code targets C++20 with Qt6. Use 4-space indentation, line up braces with Qt Creator defaults, and prefer Qt naming: classes in PascalCase (`MainWindow`), stack variables in camelCase, constants as `kCamelCase`, and translated strings via `tr()`. Keep UI strings in `mainwindow.ui` or `translations/*.ts` and register new assets in `images.qrc` so the linker can package them.

## Testing Guidelines
There is no automated test suite yet, so contributors must perform manual QA: run the binary, verify category filtering, ensure tool launch commands respect live vs installed environments, and confirm translations reload (set `LANG=xx_YY` before launching). When touching desktop integration, test both X11 (`QT_QPA_PLATFORM=xcb`) and Wayland sessions.

## Commit & Pull Request Guidelines
Git history favors concise, imperative subjects such as "Simplify version handling". Follow that tone, reference issue IDs when applicable, and keep scope atomic (build flags, translations, UI tweaks, etc.). PRs should describe the motivation, list key behavioral changes, mention localization updates, and attach screenshots for UI adjustments. Confirm `./build.sh` completes cleanly before requesting review.

## Localization & Assets
Whenever strings change, regenerate the `.ts` files with `lupdate` (used inside `build.sh`) and re-run `lrelease` for binary catalogs. Ship new icons at multiple resolutions inside `icons/` and update `images.qrc` plus `mx-tools.desktop` so Debian packaging picks them up.
