# Repository Guidelines

## Architecture & Project Layout

MX Tools is a Qt 6 / C++20 Qt Quick application. Keep the UI/backend boundary clear:

- `src/main.cpp` initializes `QApplication`, translations, the `QQmlApplicationEngine`, the `toolicons` image provider, and the initial `backend` and `version` QML properties.
- `src/toolmodel.{cpp,h}` contains `ToolModel`, a `QAbstractListModel` that discovers MX `.desktop` files, filters them for the current desktop/live environment, launches tools, and manages per-user menu visibility overrides. It also contains `ToolIconProvider`.
- `qml/Main.qml` owns the application window, responsive layout, search/category controls, dialogs, and backend signal handling.
- `qml/components/` contains reusable controls (`ToolCard`, `CategoryButton`, `ModernSwitch`, and `SecondaryButton`).
- `CMakeLists.txt` embeds QML and `icons/logo.svg` in the `MxTools` QML module. Add new QML files or embedded resources to `qt6_add_qml_module`; there is no standalone `.qrc` file.
- `data/`, `icons/`, and `help/` hold desktop integration, installed icons, and documentation. Translations live in `translations/`; desktop-file translations use the separate `translations-desktop-file/` workflow. Debian packaging is in `debian/`, while `PKGBUILD` and `release.sh` support Arch packaging/releases.

Do not edit or commit generated build trees and packaging scratch data such as `build/`, `obj-*`, `mx-tools_autogen/`, generated `.qm` files, or temporary `archpkgbuild.*` directories. Existing release artifacts under `debs/` are intentional; do not replace them unless the task is a release/package update.

## Build & Development Commands

- `./build.sh` — configure a Release build with Ninja in `build/` and build `build/mx-tools`.
- `./build.sh --debug` — build with debug symbols.
- `./build.sh --clang` — select Clang; combine with `--debug` when useful.
- `./build.sh --clean` — remove prior build/package scratch data before rebuilding.
- `./build.sh --debian` — build Debian packages with `debuild` and collect artifacts in `debs/`.
- `./build.sh --arch` — build an Arch package with `makepkg` and place it in `build/`.
- `cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel` — equivalent manual build. The version normally comes from `debian/changelog`; non-Debian packaging may pass `-DPROJECT_VERSION_OVERRIDE=<version>`.

Run a development build with `./build/mx-tools`. The program discovers launchers from `/usr/share/applications`, so meaningful manual testing requires an MX-like host or representative desktop files. `main.cpp` selects `xcb` when only `DISPLAY` is present; an existing `QT_QPA_PLATFORM` is respected.

## Coding & UI Conventions

Use 4-space indentation and the surrounding Qt style. C++ classes use PascalCase, methods and locals use camelCase, and compile-time constants follow the existing lower-camel namespace-constant style. Preserve `[[nodiscard]]`, `const`, `QStringLiteral`, and `QLatin1String` usage where appropriate. The build enables strict warnings and treats all warnings as errors.

Keep platform and filesystem behavior in C++ and presentation/state binding in QML. When extending `ToolModel`, update roles, `roleNames()`, properties, notification signals, and the QML delegate together. Preserve model reset/change notifications so views refresh correctly. Menu visibility code writes user overrides under `~/.local/share/applications` and records restoration state; changes there must remain atomic and must preserve user modifications.

In QML, use Qt Quick Layouts rather than conflicting manual geometry, expose required delegate/component inputs with `required property`, and maintain keyboard focus and `Accessible` metadata. Derive colors from `SystemPalette` and the palette properties in `Main.qml`; do not hard-code a light-only or dark-only scheme. Use `qsTr()` for QML UI text and `tr()` for C++ text.

## Localization & Assets

`qt6_add_translations` collects `translations/*.ts` (except `mx-tools_en_US.ts`) and generates compressed `.qm` catalogs during the build. After changing translatable strings, update the TS sources with the Qt Linguist/CMake translation target or `lupdate`, review the diff, and rebuild so `lrelease` validates the catalogs. Do not hand-edit generated `.qm` files. Follow the scripts and README in `translations-desktop-file/` for changes to `data/mx-tools.desktop` translations.

Use theme icon names for discovered tools and retain the bundled logo fallback. Add application icons to `icons/`, update the QML module resources when they are used from QML, and update `debian/install` and `PKGBUILD` when an installed asset changes.

## Verification

There is currently no automated test target. At minimum, ensure `./build.sh` completes without warnings. For UI/backend changes, manually verify startup, responsive wide and compact layouts, category filtering, search, condensed view, dialogs, themed icons, and tool launching. Exercise empty-result and launch-error states when relevant.

For discovery/filtering changes, check `OnlyShowIn`, `NotShowIn`, `MX-OnlyLive`, `MX-OnlyInstalled`, exact MX category matching, translated desktop entries, and live-versus-installed exclusions. For menu visibility changes, test hide and restore behavior without losing pre-existing user desktop overrides. Test theme-sensitive UI in light and dark themes; when desktop/platform integration changes, check both X11 (`QT_QPA_PLATFORM=xcb`) and Wayland.

For localization checks, remember that the application loads installed catalogs from `/usr/share/mx-tools/locale`; test a staged/installed package or arrange an equivalent locale tree before launching with `LANG=<locale>`.

## Commits & Pull Requests

Use concise, imperative commit subjects consistent with history (for example, `Preserve menu customizations`). Keep changes atomic and avoid committing unrelated generated files. PRs should explain motivation and behavioral impact, call out translation or packaging changes, list manual verification, and include screenshots for visible QML changes. Complete a clean build before requesting review.
