Format: 3.0 (native)
Source: mx-tools
Binary: mx-tools
Architecture: any
Version: 26.08
Maintainer: Adrian <adrian@mxlinux.org>
Homepage: https://github.com/MX-Linux/mx-tools
Standards-Version: 4.5.1
Vcs-Git: git://github.com/MX-Linux/mx-tools
Build-Depends: debhelper-compat (= 12), cmake (>= 3.16), ninja-build, qt6-base-dev, qt6-base-dev-tools, qt6-declarative-dev, qt6-tools-dev, qt6-tools-dev-tools
Package-List:
 mx-tools deb admin optional arch=any
Checksums-Sha1:
 313a6c4aecf273d57afd222ae8683be4f3bbfb58 12046504 mx-tools_26.08.tar.xz
Checksums-Sha256:
 4f8082aa4459d99a7d0b1a4b84785baf25b83109caa7978e4332c86a5a724dc5 12046504 mx-tools_26.08.tar.xz
Files:
 65ac41e2d2d0b995e5b41189ee8fd1bf 12046504 mx-tools_26.08.tar.xz
