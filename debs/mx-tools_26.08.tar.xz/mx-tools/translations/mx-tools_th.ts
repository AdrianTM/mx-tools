<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="th">
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="22"/>
        <location filename="../qml/Main.qml" line="81"/>
        <location filename="../qml/Main.qml" line="502"/>
        <source>MX Tools</source>
        <translation type="unfinished">MX Tools</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="88"/>
        <source>System dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="134"/>
        <source>Search tools and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="109"/>
        <source>Search tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="147"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="155"/>
        <source>Manual</source>
        <translation type="unfinished">คู่มือ</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="164"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="196"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="362"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="375"/>
        <source>Show more tools at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="373"/>
        <source>Use condensed tool view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="240"/>
        <source>Simplify menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="247"/>
        <source>Keep tools here only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="260"/>
        <location filename="../qml/Main.qml" line="446"/>
        <location filename="../qml/Main.qml" line="457"/>
        <source>Hide individual tools from the application menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="328"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="330"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="337"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="338"/>
        <source>Choose a tool to configure or maintain your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="347"/>
        <source>%n tool(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="433"/>
        <source>No tools found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="470"/>
        <source>About MX Tools</source>
        <translation type="unfinished">เกี่ยวกับ MX Tools</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="509"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="515"/>
        <source>A focused collection of configuration and maintenance tools for MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="524"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="532"/>
        <source>License</source>
        <translation type="unfinished">สัญญาอนุญาต</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="540"/>
        <source>Changelog</source>
        <translation type="unfinished">Changelog</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="550"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MX Tools</source>
        <translation type="vanished">MX Tools</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">เกี่ยวกับแอปพลิเคชันนี้</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">เกี่ยวกับ...</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">ปิดแอปพลิเคชัน</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">ปิด</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="vanished">คู่มือ</translation>
    </message>
    <message>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation type="vanished">แอปพลิเคชัน MX เหล่านี้ช่วยประหยัดเวลาสำหรับงานที่สำคัญ</translation>
    </message>
    <message>
        <source>Hide individual tools from the menu</source>
        <translation type="vanished">ซ่อนแต่ละเครื่องมือจากเมนู</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">ค้นหา</translation>
    </message>
    <message>
        <source>About MX Tools</source>
        <translation type="vanished">เกี่ยวกับ MX Tools</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">เวอร์ชัน:</translation>
    </message>
    <message>
        <source>Configuration Tools for MX Linux</source>
        <translation type="vanished">เครื่องมือตั้งค่าสำหรับ MX Linux</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">สงวนลิขสิทธิ์ (c) MX Linux</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">สัญญาอนุญาต</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Changelog</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">ยกเลิก</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;ปิด</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="79"/>
        <source>Open this MX tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolModel</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="59"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="62"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="65"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="68"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="70"/>
        <source>Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="217"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="388"/>
        <location filename="../src/toolmodel.cpp" line="403"/>
        <location filename="../src/toolmodel.cpp" line="412"/>
        <source>Unable to launch tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="388"/>
        <source>The selected tool is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="394"/>
        <source>Tool already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="394"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="403"/>
        <source>The selected tool has no launch command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="412"/>
        <source>Could not start %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="421"/>
        <location filename="../src/toolmodel.cpp" line="445"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="427"/>
        <source>Manual unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="432"/>
        <source>License unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="438"/>
        <source>Website unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="438"/>
        <source>Could not open the MX Linux website.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="445"/>
        <location filename="../src/toolmodel.cpp" line="451"/>
        <source>Changelog unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="451"/>
        <source>Could not read the application changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="454"/>
        <source>Changelog</source>
        <translation type="unfinished">Changelog</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="469"/>
        <location filename="../src/toolmodel.cpp" line="479"/>
        <source>Menu setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="469"/>
        <source>Could not create %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="479"/>
        <source>Could not update %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
