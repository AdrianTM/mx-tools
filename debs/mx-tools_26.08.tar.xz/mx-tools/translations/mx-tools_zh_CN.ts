<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="17"/>
        <location filename="../qml/Main.qml" line="73"/>
        <location filename="../qml/Main.qml" line="406"/>
        <source>MX Tools</source>
        <translation type="unfinished">MX 工具</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="80"/>
        <source>System dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="95"/>
        <source>Search tools and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="101"/>
        <source>Search tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="126"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="134"/>
        <source>Manual</source>
        <translation type="unfinished">手册</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="143"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="175"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="218"/>
        <source>Simplify menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="225"/>
        <source>Keep tools here only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="236"/>
        <location filename="../qml/Main.qml" line="364"/>
        <location filename="../qml/Main.qml" line="373"/>
        <source>Hide individual tools from the application menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="287"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="289"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="296"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="297"/>
        <source>Choose a tool to configure or maintain your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="306"/>
        <source>%n tool(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="351"/>
        <source>No tools found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="386"/>
        <source>About MX Tools</source>
        <translation type="unfinished">关于 MX 工具</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="413"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="419"/>
        <source>A focused collection of configuration and maintenance tools for MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="428"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="436"/>
        <source>License</source>
        <translation type="unfinished">许可证</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="444"/>
        <source>Changelog</source>
        <translation type="unfinished">更新日志</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="454"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MX Tools</source>
        <translation type="vanished">MX 工具</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">关于此软件</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">关于…</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">关闭程序</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="vanished">手册</translation>
    </message>
    <message>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation type="vanished">这些 MX 应用程序可以节省时间和精力来完成重要任务。</translation>
    </message>
    <message>
        <source>Hide individual tools from the menu</source>
        <translation type="vanished">从菜单中隐藏单个工具</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">搜索</translation>
    </message>
    <message>
        <source>About MX Tools</source>
        <translation type="vanished">关于 MX 工具</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">版本：</translation>
    </message>
    <message>
        <source>Configuration Tools for MX Linux</source>
        <translation type="vanished">MX Linux 的配置工具</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">Copyright (c) MX Linux</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">%1 许可证</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">许可证</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">更新日志</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">关闭(&amp;C)</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="74"/>
        <source>Open this MX tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolModel</name>
    <message>
        <location filename="../toolmodel.cpp" line="59"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="62"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="65"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="68"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="70"/>
        <source>Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="217"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="388"/>
        <location filename="../toolmodel.cpp" line="395"/>
        <location filename="../toolmodel.cpp" line="403"/>
        <source>Unable to launch tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="388"/>
        <source>The selected tool is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="395"/>
        <source>The selected tool has no launch command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="403"/>
        <source>Could not start %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="410"/>
        <location filename="../toolmodel.cpp" line="434"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="416"/>
        <source>Manual unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="421"/>
        <source>License unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="427"/>
        <source>Website unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="427"/>
        <source>Could not open the MX Linux website.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="434"/>
        <location filename="../toolmodel.cpp" line="440"/>
        <source>Changelog unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="440"/>
        <source>Could not read the application changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="443"/>
        <source>Changelog</source>
        <translation type="unfinished">更新日志</translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="458"/>
        <location filename="../toolmodel.cpp" line="468"/>
        <source>Menu setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="458"/>
        <source>Could not create %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolmodel.cpp" line="468"/>
        <source>Could not update %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
